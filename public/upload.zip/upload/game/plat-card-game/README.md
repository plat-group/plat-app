# Plats Memory Card Game

This game was created for demo purpose.
It was folked from https://saelsa.github.io/memory-card-game
